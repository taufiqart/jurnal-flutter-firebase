import 'package:e_jupe_skensa/models/UserModel.dart';

class AbsensiModel {
  String absensi;
  int createdAt;
  int updatedAt;
  String? status;
  String userUid;
  UserModel user;
  AbsensiModel({
    required this.absensi,
    this.status,
    required this.createdAt,
    required this.updatedAt,
    required this.userUid,
    required this.user,
  });
}
