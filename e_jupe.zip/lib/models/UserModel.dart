class UserModel {
  String uid;
  String fullName;
  String email;
  String? profile;
  String password;
  String role;
  UserModel({
    required this.uid,
    required this.fullName,
    this.profile,
    required this.email,
    required this.password,
    required this.role,
  });
}
