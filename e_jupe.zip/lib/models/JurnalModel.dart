import 'package:e_jupe_skensa/models/UserModel.dart';

class JurnalModel {
  String judul;
  String deskripsi;
  int createdAt;
  int updatedAt;
  String userUid;
  UserModel user;
  JurnalModel({
    required this.judul,
    required this.deskripsi,
    required this.createdAt,
    required this.updatedAt,
    required this.userUid,
    required this.user,
  });
}
