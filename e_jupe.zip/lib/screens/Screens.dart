import 'package:e_jupe_skensa/components/NavigationBarOverlay.dart';
import 'package:e_jupe_skensa/components/NavigationBarOverlayItem.dart';
import 'package:e_jupe_skensa/screens/Home.dart';
import 'package:e_jupe_skensa/screens/Profile.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class Screens extends StatefulWidget {
  final int selectedIndex;
  const Screens({super.key, this.selectedIndex = 0});

  @override
  State<Screens> createState() => _ScreensState();
}

class _ScreensState extends State<Screens> with SingleTickerProviderStateMixin {
  var _selectedIndex = 0;
  @override
  Widget build(BuildContext context) {
    return NavigationBarOverlay(
      items: [
        NavigationBarOverlayItem(
          selected: _selectedIndex == 0,
          onPress: () {
            setState(() {
              _selectedIndex = 0;
            });
          },
          child: FaIcon(
            FontAwesomeIcons.house,
            color: Colors.cyan.shade300,
          ),
        ),
        NavigationBarOverlayItem(
          selected: _selectedIndex == 1,
          onPress: () {
            setState(() {
              _selectedIndex = 1;
            });
          },
          child: FaIcon(
            FontAwesomeIcons.userLarge,
            color: Colors.cyan.shade300,
          ),
        ),
      ],
      page: [Home(), Profile()][_selectedIndex],
    );
  }
}
