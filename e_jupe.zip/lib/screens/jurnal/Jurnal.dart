import 'package:e_jupe_skensa/components/ButtonCard.dart';
import 'package:e_jupe_skensa/config/variable.dart';
import 'package:e_jupe_skensa/models/JurnalModel.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class Jurnal extends StatefulWidget {
  const Jurnal({super.key});

  @override
  State<Jurnal> createState() => _JurnalState();
}

class _JurnalState extends State<Jurnal> {
  void detailJurnal(jurnal) {
    Navigator.pushNamed(context, detailJurnalRoute,
        arguments: jurnal as JurnalModel);
  }

  @override
  Widget build(BuildContext context) {
    var screen = MediaQuery.of(context).size;
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarBrightness: Brightness.dark,
        statusBarIconBrightness: Brightness.dark,
      ),
    );
    return Scaffold(
      body: Container(
        width: screen.width,
        height: screen.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradientPrimary,
            transform: GradientRotation(40),
          ),
        ),
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).viewPadding.top + 70,
              width: screen.width,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(
                  bottom: Radius.circular(30),
                ),
              ),
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).viewPadding.top,
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Stack(
                  alignment: Alignment.centerLeft,
                  children: [
                    Container(
                      width: screen.width,
                      alignment: Alignment.center,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(9999),
                          color: Colors.grey.shade300.withOpacity(0.5),
                        ),
                        height: 40,
                        padding: EdgeInsets.symmetric(horizontal: 30),
                        // alignment: Alignment.bottomCenter,
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              isiJurnalText,
                              style: GoogleFonts.poppins(
                                fontSize: 18,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Material(
                      color: Colors.grey.shade300.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(99999),
                      clipBehavior: Clip.antiAlias,
                      child: InkWell(
                        splashColor: Colors.white54,
                        onTap: () => {Navigator.pop(context)},
                        child: Container(
                          width: 40,
                          height: 40,
                          alignment: Alignment.center,
                          child: FaIcon(
                            FontAwesomeIcons.arrowLeft,
                            color: Colors.black.withOpacity(0.6),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              height: screen.height * 0.14,
              margin: EdgeInsets.symmetric(horizontal: 20, vertical: 40),
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.blue.shade500,
                    blurRadius: 10,
                    spreadRadius: -5,
                    offset: Offset(0, 5),
                    blurStyle: BlurStyle.outer,
                  )
                ],
                gradient: LinearGradient(colors: gradientFour),
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  splashColor: Colors.red.shade100,
                  onTap: () {
                    Navigator.pushNamed(context, isiJurnalRoute);
                  },
                  child: Container(
                    alignment: Alignment.center,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        FaIcon(
                          FontAwesomeIcons.piedPiper,
                          size: 35,
                          color: Colors.blue.shade700,
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Text(
                          isiJurnalText,
                          style: GoogleFonts.poppins(
                            fontSize: 24,
                            fontWeight: semibold,
                            color: Colors.blue.shade700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Expanded(
              child: Container(
                  width: screen.width,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(30),
                    ),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(
                      vertical: 15,
                      horizontal: 20,
                    ),
                    child: Column(
                      children: [
                        ...historyJurnal.map((history) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                              vertical: 5,
                            ),
                            child: ButtonCard(
                              child: Container(
                                padding: const EdgeInsets.only(
                                  top: 10,
                                  left: 10,
                                  bottom: 10,
                                ),
                                // width: screen.width * 0.7,
                                // height: 110,
                                child: Row(
                                  children: [
                                    Container(
                                      width: 50,
                                      height: 50,
                                      decoration: BoxDecoration(
                                        color: Colors.green.shade200,
                                        borderRadius: BorderRadius.circular(
                                          999,
                                        ),
                                      ),
                                      alignment: Alignment.center,
                                      child: const FaIcon(
                                        FontAwesomeIcons.piedPiper,
                                        color: Colors.white,
                                        size: 25,
                                      ),
                                    ),
                                    const SizedBox(
                                      width: 8,
                                    ),
                                    Expanded(
                                      // width: screen.width * 0.45,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            DateFormat('dd/MM/yyyy hh:mm:ss')
                                                .format(
                                                  DateTime
                                                      .fromMillisecondsSinceEpoch(
                                                    history.createdAt,
                                                  ),
                                                )
                                                .toString(),
                                          ),
                                          if (user.role != 'siswa')
                                            Text(
                                              history.user.fullName,
                                              overflow: TextOverflow.fade,
                                              softWrap: false,
                                              style: GoogleFonts.poppins(),
                                            ),
                                          Text(
                                            history.judul,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              onPress: () {
                                detailJurnal(history);
                              },
                            ),
                          );
                        }).toList(),
                      ],
                    ),
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
