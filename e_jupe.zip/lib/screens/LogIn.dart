import 'package:e_jupe_skensa/components/Button.dart';
import 'package:e_jupe_skensa/config/variable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';

class LogIn extends StatefulWidget {
  const LogIn({super.key});

  @override
  State<LogIn> createState() => _LogInState();
}

class _LogInState extends State<LogIn> {
  double spaceField = 7;
  final _formKey = GlobalKey<FormState>();
  var _txtEmail = TextEditingController();
  var _txtPass = TextEditingController();
  bool _passwordVisible = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _passwordVisible = false;
  }

  void login() {
    _formKey.currentState!.validate();
    Navigator.pushReplacementNamed(context, homeRoute);

    print('masuk');
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarIconBrightness: Brightness.light,
      ),
    );
    var screen = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        width: screen.width,
        height: screen.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradientPrimary,
          ),
        ),
        alignment: Alignment.center,
        child: SafeArea(
          child: Container(
            height: screen.height,
            width: screen.width,
            child: Stack(
              alignment: Alignment.topCenter,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 40),
                      child: Lottie.asset(
                        loginAnimation,
                        width: screen.width * 0.9,
                      ),
                    ),
                    Lottie.asset(waveAnimation),
                  ],
                ),
                Container(
                  height: screen.height,
                  width: screen.width,
                  child: Center(
                    child: Container(
                      width: screen.width * 0.85,
                      decoration: BoxDecoration(
                        color: Colors.white54,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      padding:
                          EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            loginText,
                            style: GoogleFonts.poppins(
                              fontSize: 20,
                              fontWeight: semibold,
                            ),
                          ),
                          SizedBox(
                            height: spaceField,
                          ),
                          Form(
                            key: _formKey,
                            child: Container(
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                mainAxisSize: MainAxisSize.max,
                                children: [
                                  TextFormField(
                                    controller: _txtEmail,
                                    cursorColor: fieldPrimary,
                                    decoration: InputDecoration(
                                      alignLabelWithHint: false,
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                          width: 1.2,
                                          color: fieldPrimary,
                                        ),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                          width: 1.2,
                                          color: fieldPrimary,
                                        ),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                          width: 1.2,
                                          color: Colors.blue.shade500,
                                        ),
                                      ),
                                      focusedErrorBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                          color: Colors.blue.shade500,
                                          width: 1.2,
                                        ),
                                      ),
                                      errorBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                          width: 1.2,
                                          color: Colors.pink.shade400,
                                        ),
                                      ),
                                      contentPadding: EdgeInsets.symmetric(
                                        vertical: 2,
                                        horizontal: 10,
                                      ),
                                      errorStyle: GoogleFonts.poppins(
                                        fontWeight: FontWeight.w300,
                                        height: 0.5,
                                      ),
                                      fillColor: Colors.white70,
                                      filled: true,
                                      hintText: emailText,
                                      hintStyle: GoogleFonts.poppins(
                                        color: fieldPrimary,
                                        fontSize: 14,
                                      ),
                                    ),
                                    validator: (value) {
                                      if (value == null ||
                                          value.isEmpty ||
                                          value.trim() == '') {
                                        return emailEmpty;
                                      }
                                      return null;
                                    },
                                  ),
                                  SizedBox(height: spaceField),
                                  TextFormField(
                                    obscureText: !_passwordVisible,
                                    controller: _txtPass,
                                    cursorColor: fieldPrimary,
                                    decoration: InputDecoration(
                                      suffixIcon: IconButton(
                                        icon: Icon(
                                          // Based on passwordVisible state choose the icon
                                          _passwordVisible
                                              ? Icons.visibility
                                              : Icons.visibility_off,
                                          color: Colors.black87,
                                        ),
                                        onPressed: () {
                                          // Update the state i.e. toogle the state of passwordVisible variable
                                          setState(() {
                                            _passwordVisible =
                                                !_passwordVisible;
                                          });
                                        },
                                      ),
                                      alignLabelWithHint: false,
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                          width: 1.2,
                                          color: fieldPrimary,
                                        ),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                          width: 1.2,
                                          color: fieldPrimary,
                                        ),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                          width: 1.2,
                                          color: Colors.blue.shade500,
                                        ),
                                      ),
                                      focusedErrorBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                          width: 1.2,
                                          color: Colors.blue.shade500,
                                        ),
                                      ),
                                      errorBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                          width: 1.2,
                                          color: Colors.pink.shade400,
                                        ),
                                      ),
                                      contentPadding: EdgeInsets.symmetric(
                                        vertical: 2,
                                        horizontal: 10,
                                      ),
                                      errorStyle: GoogleFonts.poppins(
                                        fontWeight: FontWeight.w300,
                                        height: 0.5,
                                      ),
                                      fillColor: Colors.white70,
                                      filled: true,
                                      hintText: passwordText,
                                      hintStyle: GoogleFonts.poppins(
                                        color: fieldPrimary,
                                        fontSize: 14,
                                      ),
                                    ),
                                    validator: (value) {
                                      if (value == null ||
                                          value.isEmpty ||
                                          value.trim() == '') {
                                        return passwordEmpty;
                                      }
                                      return null;
                                    },
                                  ),
                                  SizedBox(
                                    height: spaceField * 3,
                                  ),
                                  Button(
                                    onPress: () => {login()},
                                    height: 45,
                                    borderRadius: BorderRadius.circular(10),
                                    child: Text(
                                      loginText,
                                      style: GoogleFonts.poppins(
                                        color: textPrimary,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            alignment: Alignment.center,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  accountNotExistText,
                                  style: GoogleFonts.poppins(
                                    color: Colors.grey.shade700,
                                  ),
                                ),
                                SizedBox(
                                  width: 4,
                                ),
                                InkWell(
                                  onTap: () => {
                                    Navigator.pushNamed(context, signupRoute)
                                  },
                                  child: Text(
                                    signupText.toLowerCase(),
                                    style: GoogleFonts.poppins(
                                      color: Colors.blue.shade700,
                                    ),
                                  ),
                                )
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
