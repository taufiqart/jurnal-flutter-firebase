import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarIconBrightness: Brightness.dark,
      ),
    );
    var screen = MediaQuery.of(context).size;
    return Scaffold(
      body: Container(
        width: screen.width,
        height: screen.height,
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            Positioned(
              // left: 50,
              width: screen.width * 1.2,
              left: screen.height * 0.01 + 40,
              child: Transform.rotate(
                angle: 45.2,
                child: Container(
                  height: screen.height * 0.54,
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xff6366F1).withOpacity(0.5),
                        blurRadius: 10,
                        offset: Offset(0, 5),
                      ),
                    ],
                    // color: Colors.blue,
                    gradient: LinearGradient(
                      colors: [Color(0xffC4B5FD), Color(0xff6366F1)],
                    ),
                    borderRadius: BorderRadius.vertical(
                      bottom: Radius.circular(99999),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: screen.height * 0.01,
              right: screen.height * 0.01 - 30,
              width: screen.width * 1.4,
              child: Transform.rotate(
                angle: 170.1,
                child: Container(
                  height: screen.height * 0.55,
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.blue.shade100, Colors.blue.shade500],
                      ),
                      // color: Colors.green,
                      borderRadius: BorderRadius.vertical(
                        bottom: Radius.circular(99999),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.blue.shade300.withOpacity(0.5),
                          blurRadius: 10,
                          offset: Offset(0, 5),
                        ),
                      ]),
                ),
              ),
            ),
            Positioned(
              width: screen.width * 1.2,
              child: Container(
                height: screen.height * 0.5,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(
                    bottom: Radius.circular(999),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
