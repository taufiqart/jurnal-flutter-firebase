import 'package:e_jupe_skensa/components/ButtonCard.dart';
import 'package:e_jupe_skensa/config/variable.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  void detailJurnal(jurnal) {
    Navigator.pushNamed(context, detailJurnalRoute);
  }

  void fullJurnal() {
    Navigator.pushNamed(context, jurnalRoute);
  }

  void fullAbsensi() {
    Navigator.pushNamed(context, absensiRoute);
  }

  @override
  Widget build(BuildContext context) {
    var screen = MediaQuery.of(context).size;
    return Scaffold(
      body: Container(
        width: screen.width,
        height: screen.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: gradientPrimary,
            transform: GradientRotation(40),
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                height: screen.height * 0.22,
                padding: EdgeInsets.only(top: 10, left: 20, right: 20),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          width: screen.width * 0.7,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Selamat pagi.',
                                style: GoogleFonts.poppins(
                                  color: textPrimary,
                                  fontSize: 16,
                                ),
                              ),
                              Text(
                                user.fullName,
                                style: GoogleFonts.poppins(
                                  fontWeight: semibold,
                                  color: textPrimary,
                                  fontSize: 17,
                                ),
                                softWrap: true,
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 50,
                          width: 50,
                          clipBehavior: Clip.antiAlias,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: Colors.white,
                            image: DecorationImage(
                              image: NetworkImage(
                                user.profile ??
                                    'https://www.cornwallbusinessawards.co.uk/wp-content/uploads/2017/11/dummy450x450.jpg',
                              ),
                              fit: BoxFit.cover,
                            ),
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      height: 6,
                    ),
                    Container(
                      height: 60,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(colors: gradientPrimary),
                        borderRadius: BorderRadius.circular(15),
                      ),
                      alignment: Alignment.center,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          Image.asset(
                            logo,
                            height: 40,
                          ),
                          SizedBox(
                            width: 17,
                          ),
                          Column(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                nameApp,
                                style: GoogleFonts.poppins(
                                    fontWeight: semibold,
                                    color: textPrimary,
                                    fontSize: 18,
                                    height: 1),
                              ),
                              Text(
                                deskripsiApp.replaceAll('\n', ' '),
                                style: GoogleFonts.poppins(
                                  fontWeight: semibold,
                                  color: textPrimary,
                                  fontSize: 12,
                                ),
                              )
                            ],
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),
              Expanded(
                child: Container(
                  width: screen.width,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    gradient: LinearGradient(
                      colors: [
                        Colors.white,
                        Colors.white,
                        Colors.white,
                        ...gradientTertiary
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(30),
                    ),
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        SizedBox(
                          height: 20,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              ButtonCard(
                                width: screen.width * 0.42,
                                height: 80,
                                background: Colors.green.shade200,
                                shadowColor: Colors.green.shade500,
                                splashColor: Colors.green.shade500,
                                onPress: () => {
                                  Navigator.pushNamed(context, absensiRoute)
                                },
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      alignment: Alignment.center,
                                      width: 50,
                                      height: 50,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(5000),
                                      ),
                                      child: FaIcon(
                                        FontAwesomeIcons.clipboardUser,
                                        color: Colors.green.shade900,
                                        size: 30,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      'Absensi',
                                      style: GoogleFonts.poppins(
                                        color: Colors.green.shade900,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              ButtonCard(
                                width: screen.width * 0.42,
                                height: 80,
                                background: Colors.purple.shade200,
                                shadowColor: Colors.purple.shade500,
                                splashColor: Colors.purple.shade500,
                                onPress: () =>
                                    {Navigator.pushNamed(context, jurnalRoute)},
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      alignment: Alignment.center,
                                      width: 50,
                                      height: 50,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(5000),
                                      ),
                                      child: FaIcon(
                                        FontAwesomeIcons.book,
                                        color: Colors.purple.shade900,
                                        size: 30,
                                      ),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      'Jurnal',
                                      style: GoogleFonts.poppins(
                                        color: Colors.purple.shade900,
                                        fontSize: 16,
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                        Container(
                          alignment: Alignment.topLeft,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    top: 40, left: 20, right: 20),
                                child: Text(
                                  historyAbsensiText,
                                  style: GoogleFonts.poppins(
                                    fontSize: 14,
                                    fontWeight: semibold,
                                  ),
                                  textAlign: TextAlign.left,
                                ),
                              ),
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                padding: EdgeInsets.symmetric(
                                  vertical: 15,
                                  horizontal: 20,
                                ),
                                child: Row(
                                  children: [
                                    ...historyAbsensi.map((history) {
                                      return Padding(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 5,
                                        ),
                                        child: ButtonCard(
                                          child: Container(
                                            padding: EdgeInsets.all(10),
                                            width: screen.width * 0.7,
                                            height: 110,
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 70,
                                                  height: 70,
                                                  decoration: BoxDecoration(
                                                    color: history.status ==
                                                            'disetujui'
                                                        ? Colors.green.shade200
                                                        : history.status ==
                                                                'ditolak'
                                                            ? Colors
                                                                .red.shade300
                                                            : Colors
                                                                .blue.shade300,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                      999,
                                                    ),
                                                  ),
                                                  alignment: Alignment.center,
                                                  child: FaIcon(
                                                    history.status ==
                                                            'disetujui'
                                                        ? FontAwesomeIcons.check
                                                        : history.status ==
                                                                'ditolak'
                                                            ? FontAwesomeIcons
                                                                .times
                                                            : FontAwesomeIcons
                                                                .clockRotateLeft,
                                                    color: Colors.white,
                                                    size: 30,
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: 8,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      Text(
                                                        DateFormat(
                                                                'dd/MM/yyyy hh:mm:ss')
                                                            .format(
                                                              DateTime
                                                                  .fromMillisecondsSinceEpoch(
                                                                history
                                                                    .createdAt,
                                                              ),
                                                            )
                                                            .toString(),
                                                      ),
                                                      if (user.role != 'siswa')
                                                        Text(
                                                          history.user.fullName,
                                                          overflow:
                                                              TextOverflow.fade,
                                                          softWrap: false,
                                                          style: GoogleFonts
                                                              .poppins(),
                                                        ),
                                                      Text(
                                                        'Absensi : ${history.absensi}',
                                                      ),
                                                      Text(
                                                        'Status : ${history.status ?? 'pending'}',
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          onPress: () {},
                                        ),
                                      );
                                    }).toList(),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                        Container(
                          alignment: Alignment.topLeft,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                  top: 10,
                                  left: 20,
                                  right: 20,
                                ),
                                child: Text(
                                  historyJurnalText,
                                  style: GoogleFonts.poppins(
                                    fontSize: 14,
                                    fontWeight: semibold,
                                  ),
                                  textAlign: TextAlign.left,
                                ),
                              ),
                              SingleChildScrollView(
                                scrollDirection: Axis.horizontal,
                                padding: EdgeInsets.symmetric(
                                  vertical: 15,
                                  horizontal: 20,
                                ),
                                child: Row(
                                  children: [
                                    ...historyJurnal.map((history) {
                                      return Padding(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 5,
                                        ),
                                        child: ButtonCard(
                                          child: Container(
                                            padding: EdgeInsets.all(10),
                                            width: screen.width * 0.7,
                                            height: 110,
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 70,
                                                  height: 70,
                                                  decoration: BoxDecoration(
                                                    color:
                                                        Colors.green.shade200,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                      999,
                                                    ),
                                                  ),
                                                  alignment: Alignment.center,
                                                  child: FaIcon(
                                                    FontAwesomeIcons.piedPiper,
                                                    color: Colors.white,
                                                    size: 30,
                                                  ),
                                                ),
                                                SizedBox(
                                                  width: 8,
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      Text(
                                                        DateFormat(
                                                                'dd/MM/yyyy hh:mm:ss')
                                                            .format(DateTime
                                                                .fromMillisecondsSinceEpoch(
                                                              history.createdAt,
                                                            ))
                                                            .toString(),
                                                      ),
                                                      if (user.role != 'siswa')
                                                        Text(
                                                          history.user.fullName,
                                                          overflow:
                                                              TextOverflow.fade,

                                                          softWrap: false,
                                                          // maxLines: 2,
                                                          style: GoogleFonts
                                                              .poppins(),
                                                        ),
                                                      Text(
                                                        '${history.judul}',
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          onPress: () =>
                                              {detailJurnal(history)},
                                        ),
                                      );
                                    }).toList(),
                                  ],
                                ),
                              )
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
