import 'package:e_jupe_skensa/config/variable.dart';
import 'package:flutter/material.dart';

class Button extends StatefulWidget {
  final type;
  final child;
  final double? width;
  final double? height;
  final borderRadius;
  final colors;
  final borderColor;
  final double borderWidth;

  final Function onPress;

  const Button({
    super.key,
    this.type = BtnType.fill,
    this.width,
    this.child,
    this.height,
    this.borderRadius,
    this.colors,
    this.borderColor,
    this.borderWidth = 2,
    required this.onPress,
  });

  @override
  State<Button> createState() => _ButtonState();
}

class _ButtonState extends State<Button> {
  @override
  Widget build(BuildContext context) {
    print(widget.type);
    return Container(
      width: widget.width,
      height: widget.height,
      child: Stack(
        children: [
          Container(
            alignment: Alignment.center,
            decoration: BoxDecoration(
              gradient: widget.type == BtnType.fill
                  ? LinearGradient(
                      colors: widget.colors ?? gradientPrimary,
                    )
                  : null,
              border: widget.type == BtnType.border
                  ? Border.all(
                      color: widget.borderColor ?? Colors.blue,
                      width: widget.borderWidth)
                  : null,
              borderRadius: widget.borderRadius,
            ),
          ),
          Positioned.fill(
            child: Material(
              borderRadius: widget.borderRadius,
              clipBehavior: Clip.antiAlias,
              color: Colors.transparent,
              child: InkWell(
                splashColor: Colors.white54,
                onTap: () {
                  widget.onPress();
                },
                child: Container(
                  width: widget.width,
                  height: widget.height,
                  alignment: Alignment.center,
                  child: widget.child,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
