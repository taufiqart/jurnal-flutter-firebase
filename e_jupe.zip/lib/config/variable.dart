import 'package:e_jupe_skensa/models/AbsensiModel.dart';
import 'package:e_jupe_skensa/models/JurnalModel.dart';
import 'package:e_jupe_skensa/models/UserModel.dart';
import 'package:flutter/material.dart';

// routes name
var absensiRoute = '/absensi';
var jurnalRoute = '/jurnal';
var isiJurnalRoute = '/isiJurnal';
var detailJurnalRoute = '/detailJurnal';
var loginRoute = '/login';
var signupRoute = '/signup';
var onboardingRoute = '/onboarding';
var homeRoute = '/home';
var profileRoute = '/profile';

// texts
var nameApp = 'E-JuPe Skensa Pas';
var deskripsiApp = 'Aplikasi Absensi dan\nJurnal Online';
var sloganApp = 'Pantau siswa pkl dengan\naplikasi e-jupe skensa pas';
var signupText = 'Daftar';
var loginText = 'Masuk';
var infoOnboardingText = 'Masuk atau Daftar untuk mengakses aplikasi';
var fullNameText = 'Nama Lengkap';
var passwordText = 'Password';
var emailText = 'Email';
var judulText = 'Judul';
var deskripsiText = 'Deskripsi';
var fullNameEmpty = 'nama lengkap harus diisi';
var passwordEmpty = 'password harus diisi';
var emailEmpty = 'email harus diisi';
var judulEmpty = 'judul harus diisi';
var deskripsiEmpty = 'deskripsi harus diisi';
var roleEmpty = 'harus diisi';
var signupAsText = 'Daftar sebagai';
var accountExistText = 'Sudah punya akun ';
var accountNotExistText = 'Belum punya akun ';
var jurnalText = 'Jurnal';
var absensiText = 'Absensi';
var historyAbsensiText = 'History Absensi';
var historyJurnalText = 'History Jurnal';
var isiJurnalText = 'Isi Jurnal';
var detailJurnalText = 'Detail Jurnal';
var submitText = 'Kirim';

List role = ['Siswa', 'Pembimbing', 'Humas'];

// var emailText = 'Email';
// colors
var gradientPrimary = [const Color(0xff618cff), const Color(0xffAEDDFF)];
var gradientSecondary = [Colors.blue.shade300, Colors.blue.shade200];
var gradientTertiary = [Colors.white, Colors.grey.shade200];
var gradientFour = [Colors.white, Colors.red.shade100];
var textPrimary = Colors.white;
var fieldPrimary = Colors.grey.shade600;
// fontsizes
var semibold = FontWeight.w600;

// enumerate
enum BtnType { fill, border }

// path
var logo = 'assets/images/logo.png';
var calendar = 'assets/images/calendar.png';
var waveAnimation = 'assets/animations/wave-lottie.json';
var loginAnimation = 'assets/animations/login-lottie.json';
var documentAnimation = 'assets/animations/document-lottie.json';

var user = UserModel(
  uid: 'sasa',
  email: 'taufiqart@gmail.com',
  fullName: 'MUKHAMMAD TAUFIQURROCHMAN',
  profile:
      'https://sps.widyatama.ac.id/wp-content/uploads/2020/08/dummy-profile-pic-female-300n300.jpg',
  password: 'alskalsasa',
  role: 'siswa',
);

List<AbsensiModel> historyAbsensi = <AbsensiModel>[
  AbsensiModel(
    absensi: 'pulang',
    createdAt: DateTime.now().millisecondsSinceEpoch,
    updatedAt: DateTime.now().millisecondsSinceEpoch,
    userUid: user.uid,
    user: user,
  ),
  AbsensiModel(
    absensi: 'masuk',
    createdAt: DateTime.now().millisecondsSinceEpoch,
    updatedAt: DateTime.now().millisecondsSinceEpoch,
    userUid: user.uid,
    status: 'disetujui',
    user: user,
  ),
  AbsensiModel(
    absensi: 'pulang',
    createdAt: DateTime.now().millisecondsSinceEpoch,
    updatedAt: DateTime.now().millisecondsSinceEpoch,
    userUid: user.uid,
    status: 'ditolak',
    user: user,
  ),
  AbsensiModel(
    absensi: 'masuk',
    createdAt: DateTime.now().millisecondsSinceEpoch,
    updatedAt: DateTime.now().millisecondsSinceEpoch,
    userUid: user.uid,
    status: 'ditolak',
    user: user,
  ),
];

List<JurnalModel> historyJurnal = <JurnalModel>[
  JurnalModel(
    judul: 'Merakit Komputer',
    deskripsi: 'Merakit komputer dengan bantuan pembimbing',
    createdAt: DateTime.now().millisecondsSinceEpoch,
    updatedAt: DateTime.now().millisecondsSinceEpoch,
    userUid: user.uid,
    user: user,
  ),
  JurnalModel(
    judul: 'Entry data',
    deskripsi: 'Memasukkan data ke database',
    createdAt: DateTime.now().millisecondsSinceEpoch,
    updatedAt: DateTime.now().millisecondsSinceEpoch,
    userUid: user.uid,
    user: user,
  ),
];
